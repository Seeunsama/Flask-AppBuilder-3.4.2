Quick How to Example to show the use of SQL views
-------------------------------------------------

Simple contacts application.

Insert test data::

    $ python testdata.py

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run
