MongoEngine Example
-------------------

Simple Contacts application example using MongoEngine support for MongoDB.

Create an Admin user::

    $ fabmanager create-admin

Insert test data::

    $ python testdata.py

Run it::

    $ fabmanager run


