Composite keys Example
----------------------

Simple application showing the use of SQLAlchemy composite keys.

Insert test data::

    $ python testdata.py

Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run

