Dash embedded in FAB
-----------------------

Example of Dash embedded under flask-appbuilder

thanks to @jimmybow (https://github.com/jimmybow/Flask_template_auth_with_Dash) for the inspiration


Run it::

    $ export FLASK_APP=app/__init__.py
    $ flask fab create-admin
    $ flask run
